from django.contrib import admin
from django.urls import path, include

# This file connects URLs to the right place.
# Anything starting with api/ goes to our items app.
urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('items.urls')),
]
