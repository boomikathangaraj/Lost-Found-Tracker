from django.contrib import admin
from .models import Item


@admin.register(Item)
class ItemAdmin(admin.ModelAdmin):
    list_display = ('id', 'item_name', 'category', 'status', 'location', 'date_reported')
    search_fields = ('item_name', 'location')
    list_filter = ('status', 'category')
