from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name='Item',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('item_name', models.CharField(max_length=100)),
                ('description', models.TextField(blank=True)),
                ('category', models.CharField(choices=[('Electronics', 'Electronics'), ('Documents', 'Documents'), ('Clothing', 'Clothing'), ('Accessories', 'Accessories'), ('Books', 'Books'), ('Other', 'Other')], default='Other', max_length=20)),
                ('location', models.CharField(max_length=100)),
                ('status', models.CharField(choices=[('Lost', 'Lost'), ('Found', 'Found'), ('Claimed', 'Claimed')], default='Lost', max_length=10)),
                ('contact_info', models.CharField(help_text='Phone or email to contact', max_length=100)),
                ('date_reported', models.DateTimeField(auto_now_add=True)),
            ],
            options={
                'ordering': ['-date_reported'],
            },
        ),
    ]
