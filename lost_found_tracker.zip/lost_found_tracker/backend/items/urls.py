from rest_framework.routers import DefaultRouter
from .views import ItemViewSet

# DefaultRouter automatically creates all the standard CRUD URLs for us
router = DefaultRouter()
router.register(r'items', ItemViewSet, basename='item')

urlpatterns = router.urls
