from rest_framework import serializers
from .models import Item


class ItemSerializer(serializers.ModelSerializer):
    """
    A serializer is like a translator:
    it converts our Python Item objects into JSON (for the frontend)
    and converts incoming JSON back into Item objects (when saving).
    """

    class Meta:
        model = Item
        fields = [
            'id',
            'item_name',
            'description',
            'category',
            'location',
            'status',
            'contact_info',
            'date_reported',
        ]
        read_only_fields = ['id', 'date_reported']

    def validate_item_name(self, value):
        # Simple validation: item name should not be empty or just spaces
        if not value.strip():
            raise serializers.ValidationError("Item name cannot be empty.")
        return value

    def validate_contact_info(self, value):
        if not value.strip():
            raise serializers.ValidationError("Contact info cannot be empty.")
        return value
