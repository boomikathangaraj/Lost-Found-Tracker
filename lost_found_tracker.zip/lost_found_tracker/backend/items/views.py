from rest_framework import viewsets, status
from rest_framework.response import Response
from django.db.models import Q
from .models import Item
from .serializers import ItemSerializer


class ItemViewSet(viewsets.ModelViewSet):
    """
    ModelViewSet automatically gives us these endpoints:

      GET    /api/items/          -> see the list of all items
      POST   /api/items/          -> add (create) a new item
      GET    /api/items/<id>/     -> see one single item
      PUT    /api/items/<id>/     -> update an item completely
      PATCH  /api/items/<id>/     -> update only some fields of an item
      DELETE /api/items/<id>/     -> delete an item

    We only write extra code below where we need something custom,
    like searching or nicer response messages.
    """

    queryset = Item.objects.all()
    serializer_class = ItemSerializer

    def get_queryset(self):
        # Support ?search=... and ?status=... in the URL for filtering
        queryset = Item.objects.all()

        search_text = self.request.query_params.get('search')
        if search_text:
            queryset = queryset.filter(
                Q(item_name__icontains=search_text) |
                Q(location__icontains=search_text) |
                Q(category__icontains=search_text)
            )

        status_filter = self.request.query_params.get('status')
        if status_filter:
            queryset = queryset.filter(status=status_filter)

        return queryset

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        instance.delete()
        return Response({"message": "Item deleted successfully."}, status=status.HTTP_204_NO_CONTENT)
