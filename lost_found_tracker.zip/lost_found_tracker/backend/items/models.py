from django.db import models


class Item(models.Model):
    """
    This model represents one lost or found item report.
    Each field here becomes a column in the database table.
    """

    # Dropdown-style choices for category
    CATEGORY_CHOICES = [
        ('Electronics', 'Electronics'),
        ('Documents', 'Documents'),
        ('Clothing', 'Clothing'),
        ('Accessories', 'Accessories'),
        ('Books', 'Books'),
        ('Other', 'Other'),
    ]

    # Dropdown-style choices for status
    STATUS_CHOICES = [
        ('Lost', 'Lost'),
        ('Found', 'Found'),
        ('Claimed', 'Claimed'),
    ]

    item_name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='Other')
    location = models.CharField(max_length=100)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='Lost')
    contact_info = models.CharField(max_length=100, help_text="Phone or email to contact")
    date_reported = models.DateTimeField(auto_now_add=True)  # filled automatically when created

    class Meta:
        ordering = ['-date_reported']  # show newest reports first

    def __str__(self):
        return f"{self.item_name} ({self.status})"
